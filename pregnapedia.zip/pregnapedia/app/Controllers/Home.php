<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function view()
    {
        return view('home');
    }
    public function register(){
        $this->validation->setRule("name", "Name ", "required");
        $this->validation->setRule("email", "Email ", "required");
        $this->validation->setRule("address", "Address ", "required");
        $this->validation->setRule("number", "Number ", "required");
        $this->validation->setRule("time_to_contact", "Time to contact ", "required");
        $this->validation->setRule("average_number_of_claims", "Average number of claims ", "required");
        $this->validation->setRule("speciality", "speciality ", "required");

        if ($this->validation->withRequest($this->request)->run()) {
            $arr = array(
                'name'=> $_POST['name'],
                'email'=> $_POST['email'],
                'address'=> $_POST['address'],
                'number'=> $_POST['number'],
                'best_time_to_contact'=> $_POST['time_to_contact'],
                'avrg_claims'=> $_POST['average_number_of_claims'],
                'speciality'=> $_POST['speciality'],
            );
            // $json = array();
            $json['result'] = 400;

            if($this->db->table('details')->insert($arr)){
                $json['result'] = 200;
            }
        } else {
            $json = array(
                "error" => true,
                "name" => $this->validation->getError("name"),
                "speciality" => $this->validation->getError("speciality"),
                "email" => $this->validation->getError("email"),
                "address" => $this->validation->getError("address"),
                "number" => $this->validation->getError("number"),
                "time_to_contact" => $this->validation->getError("time_to_contact"),
                "average_number_of_claims" => $this->validation->getError("average_number_of_claims"),
            );
        }
        return $this->response->setJSON($json);
    }
    public function pregnancy()
    {
        return view('pregnancy');
    }
    public function prepregnancy()
    {
        return view('prepregnancy');
    }
    public function postpregnancy()
    {
        return view('postpregnancy');
    }

    
}
