<?php
namespace App\Models;
use CodeIgniter\Model;
class Order_mail extends Model
{
    function mail(){
        $enddate = date("Y-m-d 17:00:00");
        $startdate =  date('Y-m-d 17:00:00', (strtotime('-1 day', strtotime($enddate))));

        $order_products = $this->db->table('orders')->where('order_date >=',$startdate)->where('order_date <=',$enddate)->groupBy('vendor_id')->join('credentials as cred', 'cred.id = orders.vendor_id')->get()->getResultArray();


        return $order_products;
    }
}    

