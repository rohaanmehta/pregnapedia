<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

    <title>PREGNAPEDIA</title>
    <style>
        .content_box {
            min-height: 260px;
        }

        /* bootstrap csss   */
        button,
        textarea:focus {
            outline: none !important;
            box-shadow: none !important;
        }

        input,
        select {
            box-shadow: none !important;
            outline: none !important;
        }

        input,
        select:focus {
            border: 1px solid lightgrey !important;
        }

        .head {
            position: sticky;
            top: 0;
        }

        html {
            scroll-behavior: smooth;
        }

        .logo {
            width: 400px;
            height: 100px;
        }

        .hero_picture {
            width: 70%;
            /* height: 500px; */
        }

        .about_picture {
            width: 100%;
            /* height: 500px; */
        }

        .hero_text {
            font-size: 28px;
        }

        .content_text_heading {
            font-size: 12px;
            color: #000;
            font-weight: bold;
            margin-top: 10px;
        }

        .content_text_body {
            font-size: 16px;
            color: #ae93f6;
            font-weight: 500;
            min-height: 100px;
            /* font-weight: bold; */
        }

        .about_text_heading {
            font-size: 27px;
            color: #000;
            font-weight: bold;
        }

        .about_text_body {
            font-size: 18px;
            color: #999999;
            /* font-weight: bold; */
        }

        .copyright {
            font-size: 16px;
            color: #999999;
            /* font-weight: bold; */
        }

        .input_colour {
            background-color: #f1f1f1;
            color: #878787 !important;
        }

        .fullbar {
            display: block;
        }

        .mobilebar {
            display: none;
        }

        @media only screen and (max-width: 900px) {
            .mobilebar {
                display: block;
            }

            .fullbar {
                display: none;
            }
        }

        @media only screen and (max-width: 700px) {
            .hero_picture {
                width: 100%;
            }
        }

        .banner-img {
            border-radius: 100px;
            width: 150px !important;
        }

        .font-bold {
            font-size: 37px;
            font-weight: bolder;
        }

        .font-normal {
            font-size: 22px;
            font-weight: 500;
        }

        .font-banner-tittle {
            font-size: 21px;
            font-weight: 600;
        }

        .font-banner-desc {
            font-size: 17px;
            color: #6c6c6c;
        }
    </style>
</head>
