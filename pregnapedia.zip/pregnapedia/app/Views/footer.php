<div class='row d-flex p-3 ms-0 me-0' style='background:#6b62e3'>
            <div class='col-md-6 pt-2  text-center text-md-start'>
                <p class='text-light'>Copyright @ 2024 Pregnapedia.com </p>
            </div>
            <!-- <div class='col-md-6 text-center text-md-end'>
                <a href='' class='text-light btn btn-info me-2'><i class="fa fa-facebook" style="font-size:20px;"></i></a>
                <a href='' class='text-light btn btn-info me-2'><i class="fa fa-twitter" style="font-size:20px;"></i></a>
                <a href='' class='text-light btn btn-info me-2'><i class="fa fa-linkedin" style="font-size:20px;"></i></a>
            </div> -->
        </div>