<!DOCTYPE html>
<html lang="en">

<?php include('css.php'); ?>

<body>
    <?php include('header.php'); ?>

    <div class='container-fluid p-5 pb-0' style='background-color:#ae93f6 !important;'>
        <section id='home'>
            <div class='row d-flex m-3'>
                <div class='col-md-6 mt-5 text-center'>
                    <p class='font-bold hero_text text-light'>Get Personalized Diet Plans From
                        Best Dietician In Mumbai </p>
                    <p class='font-normal hero_text text-light mb-4'>The decision to eat healthy should not be confused with dieting. Here at Diet Therapy, we will help you to learn how to trust your food choices, how to nourish your body, and how to manage your emotions without the restrictions of diets </p>
                </div>
                <div class='col-md-6 text-center text-md-end'>
                    <img class='hero_picture rounded' src='<?= base_url('/public/uploads/dietgirl.jpg'); ?>' />
                </div>
            </div>
        </section>
    </div>

    <section id='content'>
        <div class='row d-flex mt-5'>
            <div class='col-xs-12 col-md-2'>
                <div class='content_box btn m-4 pt-4'>
                    <img class='w-100 banner-img' src='<?= base_url('public/uploads/banner1.webp') ?>'>
                    <p class='content_text_heading'>Select a program. </p>
                </div>
            </div>
            <div class='col-xs-12 col-md-2'>
                <div class='content_box btn m-4 pt-4'>
                    <img class='w-100 banner-img' src='<?= base_url('public/uploads/banner2.webp') ?>'>
                    <p class='content_text_heading'> Enroll with us by Making Payment.
                    </p>
                </div>
            </div>
            <div class='col-xs-12 col-md-2'>
                <div class='content_box btn m-4 pt-4'>
                    <img class='w-100 banner-img' src='<?= base_url('public/uploads/banner3.webp') ?>'>
                    <p class='content_text_heading'> Fill up an Assessment Form.
                    </p>
                </div>
            </div>
            <div class='col-xs-12 col-md-2'>
                <div class='content_box btn m-4 pt-4'>
                    <img class='w-100 banner-img' src='<?= base_url('public/uploads/banner4.webp') ?>'>
                    <p class='content_text_heading'> Schedule a Video Call with Dietitian Shweta </p>
                </div>
            </div>
            <div class='col-xs-12 col-md-2'>
                <div class='content_box btn m-4 pt-4'>
                    <img class='w-100 banner-img' src='<?= base_url('public/uploads/banner5.webp') ?>'>
                    <p class='content_text_heading'> Receive a Diet Plan.
                    </p>
                </div>
            </div>
            <div class='col-xs-12 col-md-2'>
                <div class='content_box btn m-4 pt-4'>
                    <img class='w-100 banner-img' src='<?= base_url('public/uploads/banner6.webp') ?>'>
                    <p class='content_text_heading'> Check up With Jr. Dietitian Every 5th day.
                    </p>
                </div>
            </div>
            <!-- <div class='col-xs-12 col-md-2'>
                <div class='content_box btn m-4 pt-4'>
                    <img class='w-100 banner-img' src='<?= base_url('public/uploads/banner7.webp') ?>'>
                    <p class='content_text_heading'> Follow up Consultation With Dietitian Shweta Every 10th Day </p>
                </div>
            </div> -->
        </div>
    </section>
    <div class='container'>
        <section id='about'>
            <div class='row d-flex m-5' style='margin-top:90px !important;margin-bottom:90px !important'>
                <div class='col-md-6 text-md-end'>
                    <img class='about_picture' src='<?= base_url('public/uploads/about.png') ?>'>
                </div>
                <div class='col-md-6'>
                    <p class='about_text_heading'>PREGNAPEDIA: Celebrity Dietician In Mumbai</p>
                    <p class='font-banner-desc'> PREGNAPEDIA is a certified clinical nutritionist. She has worked as a registered dietitian and sports nutrition for more than 5 years and specializes in providing holistic nutritional guidance to help people achieve their health goals. Her approach is integrative, emphasizing the importance of eating healthy food into a personalized treatment plan.

                        She believe that the diet doesn't have to be boring. A balanced diet is key to maintaining a healthy lifestyle. The food we consume provides our bodies with the fluids, macronutrients, micronutrients, and calories needed to function properly. </p>
                    <a href='<?= base_url('/public/uploads/diet.pdf') ?>' download>
                        <button style='background:#ae93f6' class='btn text-light rounded-pill p-2 ps-3 pe-3'>GET YOUR DIET PLAN </button>
                    </a>
                </div>
            </div>
        </section>
    </div>


    <!-- <section id='register'>
            <form id='form'>
                <div class='row d-flex m-5' style='margin-top:90px !important;margin-bottom:90px !important'>
                    <div class='col-md-6 pe-4 text-center'>
                        <input type='text' name='name' id='name' class='form-control mt-3 input_colour' placeholder='Full Name' />
                        <span class="text-danger text-left" id="error-name"></span>

                        <input type='text' name='email' id='email' class='form-control mt-3 input_colour' placeholder='Email' />
                        <span class="text-danger text-left" id="error-email"></span>

                        <input type='text' name='address' id='address' class='form-control mt-3 input_colour' placeholder='Full Address' />
                        <span class="text-danger text-left" id="error-address"></span>

                        <input type='number' name='number' id='number' class='form-control mt-3 input_colour' placeholder='Contact Number' />
                        <span class="text-danger text-left" id="error-number"></span>

                        <input type='text' name='time_to_contact' id='time_to_contact' class='form-control mt-3 input_colour' placeholder='Best time to contact' />
                        <span class="text-danger text-left" id="error-time_to_contact"></span>

                        <input type='number' name='average_number_of_claims' id='average_number_of_claims' class='form-control mt-3 input_colour' placeholder='Average number of Claims per Month' />
                        <span class="text-danger text-left" id="error-average_number_of_claims"></span>

                        <select name='speciality' id='speciality' class='form-control mt-3 input_colour'>
                            <option value=''>Select Speciality</option>
                            <option value='TEST1'>TEST1</option>
                            <option value='TEST2'>TEST2</option>
                        </select>
                        <p class="text-danger text-left" id="error-speciality"></p>

                        <button class='btn btn-danger text-light rounded-pill p-2 ps-3 pe-3 mb-5'>Send it</button>
                        <div id='msg' class='text-success' style='display:none'>Registered successfully !</div>
                    </div>
                    <div class='col-md-6 text-center text-md-end'>
                        <img class='hero_picture' src='<?= base_url('public/uploads/24x7.png') ?>'>
                        <p class='h2 text-dark'>Interested ? Register today !</p>
                    </div>
                </div>
            </form>
        </section> -->

    <div class='row'>
        <div class='text-center m-5' style='font-size:29px'>Why Choose Us for Your Weight Transformation Journey</div>
        <div class='row'>
            <div class='col-12 col-md-6'>
                <img class='w-100' src='<?= base_url('public/uploads/diet1.png'); ?>' />
            </div>
            <div class='col-12 col-md-6 p-5' style='align-self: center;'>
                <p class='font-banner-tittle'> A Complete Lifestyle Change Program! </p>
                <p class='font-banner-desc'> Diet therapy isn't just a fad diet to help you lose weight for the short-term. Our offline and online weight loss program is a sustainable program that helps you change your lifestyle for the better so you can keep the weight off permanently. Our lifestyle program does not only focus on changes to diet, exercise, sleep, and other habits but also involve education on healthy lifestyle choices. Taking one step at a time is what we follow rigorously. </p>
            </div>
        </div>
        <div class='row'>
            <div class='col-12 col-md-6 p-5' style='align-self: center;'>
                <p class='font-banner-tittle'> Customized Meal Plans</p>
                <p class='font-banner-desc'> At Diet Therapy our major focus is to provide therapeutic treatments. We understand that everyone is unique and therefore has unique dietary needs. That's why we offer customized meal plans specifically tailored to your individual medical condition such as pcos, cholesterol, renal diseases, inflammatory conditions, thyroid, metabolic syndrome & much more. This way you can be sure you're getting the right nutrients to manage your condition better.

                    And achieve your desired results, whether that's weight loss, increased energy, lifestyle disorders like PCOS, thyroid or simply improved overall health. </p>
            </div>
            <div class='col-12 col-md-6'>
                <img class='w-100' src='<?= base_url('public/uploads/diet2.png'); ?>' />
            </div>
        </div>
        <div class='row'>
            <div class='col-12 col-md-6'>
                <img class='w-100' src='<?= base_url('public/uploads/diet3.png'); ?>' />
            </div>
            <div class='col-12 col-md-6 p-5' style='align-self: center;'>
                <p class='font-banner-tittle'> We Follow Holistic Approach </p>
                <p class='font-banner-desc'> Holistic approaches to food & health focus on the whole person - not just their diet. By taking into account all aspects of a person's life (such as their environment, psychology, physiology), these approaches help people achieve healthier lifestyles and prevent chronic diseases. We believe in giving you the tools you need to make healthy changes for the long term, not just temporary fixes.

                    That's why we provide comprehensive nutritional counselling, meal planning assistance, diet tips, physical therapy exercises recommendations and more. We want you to enjoy your journey towards better health...and see results! </p>
            </div>
        </div>
        <div class='row'>
            <div class='col-12 col-md-6 p-5' style='align-self: center;'>
                <p class='font-banner-tittle'> Sustainable and Health-First
                </p>
                <p class='font-banner-desc'>The Diet Therapy team believes in creating sustainable healthy habits with proper diet. Our goal is to help you develop healthy habits that will last a lifetime. We do not believe in diet fads or quick fixes, but rather making changes that will benefit your overall health over the long-term.</p>
            </div>
            <div class='col-12 col-md-6'>
                <img class='w-100' src='<?= base_url('public/uploads/diet4.png'); ?>' />
            </div>
        </div>
    </div>
    <!-- </div> -->

    <section id='contact'>
        <div class='p-5 row text-center text-light h4 m-4 ms-0 me-0' style='background:#6b62e3'>
            <p class=''>Helped over 5000+ people with weight loss and reverse / manage lifestyle disorders. We know that works!
            </p>
        </div>
        <div class='row m-4'>
            <div class='col-12 col-md-6'>
                <img class='w-100' src='<?= base_url('public/uploads/diet5.jpg'); ?>' />
            </div>
            <div class='col-12 col-md-6'>
                <p class='font-banner-tittle'> Healthy Eating And Lifestyle Are The Key To Lasting Health </p>
                <p class='font-banner-desc'> Diet Therapy is not just a nutrition and wellness clinic but a medical nutrition therapy that was created to tackle health problems and build healthy food habits with a focus on food science. We use evidence-based clinical nutrition and dietary assessment to create personalized diet plans that are tailored specifically for each of our patients. Our team of registered dietitian nutritionist will work with you to develop an eating plan that meets your needs, while helping you achieve your health goals.

                    By incorporating healthy recipes, portion control, stress management, environment, and mindful eating into our programs, we can help reduce the symptoms of common medical conditions like Diabetes, Polycystic Ovarian Syndrome, Hypertension, Cholesterol, high Uric acid, Renal diseases, Gastrointestinal disorders, Inflammation & other issues due to modern lifestyles. This comprehensive approach has helped our clients lose weight and keep it off long-term. </p>
            </div>
        </div>

        <?php include('footer.php'); ?>

    </section>
    <script>
        function w3_open() {
            document.getElementById("mySidebar").style.display = "block";
        }

        function w3_close() {
            document.getElementById("mySidebar").style.display = "none";
        }

        $(document).ready(function() {
            $('#form').submit(function(e) {
                e.preventDefault();
                $.ajax({
                    type: "POST",
                    url: "<?= base_url('register') ?>",
                    data: new FormData(this),
                    contentType: false,
                    cache: false,
                    processData: false,
                    dataType: "json",
                    success: function(data) {
                        // console.log(data.result);
                        if (data.error) {
                            var i = 0;
                            $.each(data, function(key, value) {
                                if (value != '') {
                                    $("#error-" + key).html(value);
                                    $("#" + key).addClass("border-danger");
                                    if (i == 1) {
                                        $('#' + key).focus();
                                    }
                                    i++;
                                } else {
                                    $("#error-" + key).html(" ");
                                    $("#" + key).removeClass("border-danger");
                                }
                            });
                        }

                        if (data.result == '200') {
                            $('#msg').css('display', 'block');
                            setTimeout(function() {
                                $('#msg').css('display', 'none');
                                $('#form input[type="text"]').val('');
                                $('#form input[type="number"]').val('');
                                $('#speciality').val('');
                            }, 5000);
                        }
                    }
                });

            });
        });
    </script>
</body>

</html>