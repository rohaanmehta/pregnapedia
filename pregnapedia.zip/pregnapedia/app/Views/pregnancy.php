<!DOCTYPE html>
<html lang="en">

<?php include('css.php');?>


<body>
<?php include('header.php');?>



    <div class='row'>
        <div class='text-center m-5' style='font-size:29px'> WHAT ARE YOU GOING THROUGH ?</div>
        <div class='row'>
            <div class='col-12 col-md-6 justify-content-center d-flex' style='flex-wrap:wrap'>
                <div class='col-12 justify-content-center d-flex'>
                    <img class='preg-img' src='<?= base_url('public/uploads/prepreg.png'); ?>' />
                </div>
                <a href='<?= base_url('/prepregnancy') ?>'>
                    <button class='btn btn-lg text-light m-4' style='background:#6b62e3'>Pre Pregnancy</button>
                </a>
            </div>  <div class='col-12 col-md-6 justify-content-center d-flex' style='flex-wrap:wrap'>
                <div class='col-12 justify-content-center d-flex'>
                    <img class='preg-img' src='<?= base_url('public/uploads/postpreg.jpg'); ?>' />
                </div>
                <a href='<?= base_url('/postpregnancy') ?>'>
                    <button class='btn btn-lg text-light m-4' style='background:#6b62e3'>Post Pregnancy</button>
                </a>
            </div>
        </div>

        <section id='contact'>
        <?php include('footer.php');?>

        </section>
        <script>
            function w3_open() {
                document.getElementById("mySidebar").style.display = "block";
            }

            function w3_close() {
                document.getElementById("mySidebar").style.display = "none";
            }

            $(document).ready(function() {
                $('#form').submit(function(e) {
                    e.preventDefault();
                    $.ajax({
                        type: "POST",
                        url: "<?= base_url('register') ?>",
                        data: new FormData(this),
                        contentType: false,
                        cache: false,
                        processData: false,
                        dataType: "json",
                        success: function(data) {
                            // console.log(data.result);
                            if (data.error) {
                                var i = 0;
                                $.each(data, function(key, value) {
                                    if (value != '') {
                                        $("#error-" + key).html(value);
                                        $("#" + key).addClass("border-danger");
                                        if (i == 1) {
                                            $('#' + key).focus();
                                        }
                                        i++;
                                    } else {
                                        $("#error-" + key).html(" ");
                                        $("#" + key).removeClass("border-danger");
                                    }
                                });
                            }

                            if (data.result == '200') {
                                $('#msg').css('display', 'block');
                                setTimeout(function() {
                                    $('#msg').css('display', 'none');
                                    $('#form input[type="text"]').val('');
                                    $('#form input[type="number"]').val('');
                                    $('#speciality').val('');
                                }, 5000);
                            }
                        }
                    });

                });
            });
        </script>
</body>

</html>