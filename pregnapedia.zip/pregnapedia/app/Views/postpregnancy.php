<!DOCTYPE html>
<html lang="en">

<?php include('css.php'); ?>


<body>
    <?php include('header.php'); ?>


    <div class='row'>
        <div class='text-center m-5' style='font-size:29px'> GOING THROUGH POST PREGNANCY?</div>
        <div class='row p-5'>
            <div class='col-12 col-md-6'>
                <img class='w-100' src='<?= base_url('public/uploads/fooditems.jpg'); ?>' />
            </div>
            <div class='col-12 col-md-6 p-5' style='align-self: center;'>
                <p class='font-banner-tittle'> Regional food items and receipes </p>
                <ul class='font-banner-desc'>
                    <li> Normal & Calseran </li>
                </ul>
            </div>
        </div>
        <div class='row p-5'>
            <div class='col-12 col-md-6 p-5' style='align-self: center;'>
                <p class='font-banner-tittle'> Life style and change
                </p>
                <ul class='font-banner-desc'>
                    <li> Yoga </li>
                    <li> Exercise </li>
                </ul>
            </div>
            <div class='col-12 col-md-6'>
                <img class='w-100' src='<?= base_url('public/uploads/lifestyle.jpg'); ?>' />
            </div>
        </div>

        <section id='contact'>
            <?php include('footer.php'); ?>

        </section>
        <script>
            function w3_open() {
                document.getElementById("mySidebar").style.display = "block";
            }

            function w3_close() {
                document.getElementById("mySidebar").style.display = "none";
            }

            $(document).ready(function() {
                $('#form').submit(function(e) {
                    e.preventDefault();
                    $.ajax({
                        type: "POST",
                        url: "<?= base_url('register') ?>",
                        data: new FormData(this),
                        contentType: false,
                        cache: false,
                        processData: false,
                        dataType: "json",
                        success: function(data) {
                            // console.log(data.result);
                            if (data.error) {
                                var i = 0;
                                $.each(data, function(key, value) {
                                    if (value != '') {
                                        $("#error-" + key).html(value);
                                        $("#" + key).addClass("border-danger");
                                        if (i == 1) {
                                            $('#' + key).focus();
                                        }
                                        i++;
                                    } else {
                                        $("#error-" + key).html(" ");
                                        $("#" + key).removeClass("border-danger");
                                    }
                                });
                            }

                            if (data.result == '200') {
                                $('#msg').css('display', 'block');
                                setTimeout(function() {
                                    $('#msg').css('display', 'none');
                                    $('#form input[type="text"]').val('');
                                    $('#form input[type="number"]').val('');
                                    $('#speciality').val('');
                                }, 5000);
                            }
                        }
                    });

                });
            });
        </script>
</body>

</html>