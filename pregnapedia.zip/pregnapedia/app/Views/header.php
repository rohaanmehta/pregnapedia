
    <!-- Sidebar -->
    <div class="w3-sidebar w3-bar-block w3-border-right" style="display:none;background-color:#ae93f6 !important;" id="mySidebar">
        <button onclick="w3_close()" class="text-end w3-bar-item btn text-light btn-lg">&times;</button>
        <a href='#home' class='w3-bar-item btn text-light btn-lg'>Home</a>
        <!-- <a href='#about' class='w3-bar-item btn text-light btn-lg'>About</a> -->
        <a href='#content' class='w3-bar-item btn text-light btn-lg'>Diet</a>
        <a href='#content' class='w3-bar-item btn text-light btn-lg'>Pregnenancy</a>
        <!-- <a href='#register' class='w3-bar-item btn text-light btn-lg'>Register</a> -->
        <!-- <a href='#about' class='w3-bar-item btn text-light btn-lg'>FAQ</a> -->
        <!-- <a href='#contact' class='w3-bar-item btn text-light btn-lg'>Contact us</a> -->
    </div>
    <div class='container-fluid p-5 pt-0 pb-2 head' style='background-color:#987bd5 !important;'>
        <div class='row d-flex m-0 ms-0 mt-0' style='align-items:center'>
            <div class='col-md-5 d-flex pt-2' style='align-items:center'>
                <button class="me-3 w3-button bg-info text-light w3-xlarge mobilebar" onclick="w3_open()">☰</button>
                <!-- <i class="fa fa-clock-o me-3" style="font-size:40px;color:#fff"></i> -->
                <img width='80px' src='<?= base_url('/public/uploads/logo2.png'); ?>' />
                <p class='h5 text-light pt-2 ms-3'>PREGNAPEDIA</p>
            </div>
            <div class='col-md-7 text-end fullbar pt-3'>
                <a href='<?= base_url('/')?>' class='btn text-light btn-lg p-0 pe-3' style='font-size:17px'>Home</a>
                <!-- <a href='#about' class='btn text-light btn-lg p-0 pe-3' style='font-size:17px'>About</a> -->
                <a href='<?= base_url('pregnancy')?>' class='btn text-light btn-lg' style='font-size:17px'>Pregnancy</a>
                <a href='<?= base_url('/')?>#content' class='btn  text-light btn-lg' style='font-size:17px'>Diet</a>
                <!-- <a href='#about' class='btn text-light btn-lg p-0 pe-3' style='font-size:17px'>FAQ</a> -->
                <!-- <a href='#contact' class='btn text-light btn-lg p-0 pe-3' style='font-size:17px'>Contact us</a> -->
            </div>
        </div>
    </div>