<?php 
function create_slug($name, $id = null)
{
    $combined_dateTime = str_replace(' ', '', str_replace('-', '', date('Y-m-d H:i:s')));
    return strtolower(preg_replace('/[^A-Za-z0-9_\-]/', '', str_replace(' ', '_', $name . '_' . $combined_dateTime)));
}
?>